package question2;

public class Product {

	int id;
	String pname;
	int pprice;
	 
	Product(int id,String pname,int pprice)
	{
		this.id = id;
		this.pname = pname;
		this.pprice = pprice;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public int getPprice() {
		return pprice;
	}

	public void setPprice(int pprice) {
		this.pprice = pprice;
	}
}
