package question2;

import java.util.Scanner;

public class ecommerce {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i=0,j=0;
		Customer[] custarray = new Customer[20];
		Product[] prodarray = new Product[20];
		Scanner sc= new Scanner(System.in);
		while(true)
		{
			int selection;
			System.out.println("1. register customer");
			System.out.println("2. Create a Product");
			System.out.println("3. Create an Order");
			System.out.println("4. View orders");
			System.out.println("5. Exit");
			selection = sc.nextInt();
			if(selection == 1)
			{
				System.out.println("enter the name");
				String name = sc.next();
				System.out.println("enter the password");
				String pass = sc.next();
				Customer s=new Customer(name,pass);
				custarray[i++]=s;
				
			}
			else if(selection ==2)
			{
				System.out.println("enter the name of product");
				String pname = sc.next();
				System.out.println("enter the product price");
				int pprice = sc.nextInt();
				Product p = new Product(j+1,pname,pprice);
				prodarray[j++] = p;
			}
			else if(selection == 3)
			{
				System.out.println("enter the name");
				String name = sc.next();
				System.out.println("enter the password");
				String pass = sc.next();
				
				for(int x=0;x<i;x++)
				{
					
					if(custarray[x].name.equals(name))
					{
						if(pass.equals(custarray[x].pass))
						{
					
							custarray[x].createOrder(prodarray,j);
						}
					}
				}
			
			}
			else if(selection == 4)
			{
				System.out.println("enter the name");
				String name = sc.next();
				System.out.println("enter the password");
				String pass = sc.next();
				for(int x=0;x<i;x++)
				{
					
					if(custarray[x].name.equals(name))
					{
						if(pass.equals(custarray[x].pass))
						{
					
							custarray[x].vieworders();
						}
					}
				}
				
			}
		}
		
		
		
	}

}
