package question2;

import java.util.Scanner;

public class Customer {
	
	String name;
	String pass;
	Order ord = new Order();
	Scanner sc = new Scanner(System.in);
	
	Customer(String name,String pass)
	{
		this.name = name;
		this.pass = pass;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}

	
	public void createOrder(Product[] prodarray, int j) {
		// TODO Auto-generated method stub
		
		System.out.println("id,name,cost");
		for(int y=0;y<j;y++)
		{
			System.out.print(prodarray[y].id+",");
			System.out.print(prodarray[y].pname+",");
			System.out.println(prodarray[y].pprice);
			
		}
		System.out.println("select any id");
		int selectedid = sc.nextInt();
		System.out.println(selectedid);
		ord.addprod(selectedid);
		
	}

	public void vieworders() {
		// TODO Auto-generated method stub
		
		for(int i = 0;i<ord.i;i++)
		{
			System.out.println(ord.array[i]);
		}
	}
	

}
