package question2;

public class Order {
	 
	int i=0;
	int [] array = new int[100];
	void addprod(int id)
	{
		array[i++]=id;

	}
	 	
}
