
import java.util.Scanner;

public class findPrime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	

		
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			System.out.println("enter the number of elements");
			int elems = sc.nextInt();
			
			 int [] array = new int[elems];
			for(int i=0;i<elems ;i++) {
				
				array[i] = sc.nextInt(); 
			}
			
			for(int i=0;i<elems;i++)
			{
				
					if(isPrime(array[i]))
					{
						if(array[i]<10)
						{
							System.out.println(array[i]);
							
						}
						else {
							if(checkadditiveprime(array[i]))
							{
								System.out.println(array[i]);
							}
						}
					}
			}
					
	}

	private static boolean checkadditiveprime(int num) {
		// TODO Auto-generated method stub
		int sum = 0;
		while(num!=0)
		{
			sum+=num%10;
			num = num/10;	
		}
		
		if(isPrime(sum)) return true;
		else return false;
	}

	private static boolean isPrime(int num) {
		// TODO Auto-generated method stub
		
		for(int i=2;i<num/2;i++)
		{
			if(num%i == 0)
			{

				return false;
			}
			
		}

		return true;
		
	}

}